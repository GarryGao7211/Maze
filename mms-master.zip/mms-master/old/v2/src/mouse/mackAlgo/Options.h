#pragma once

// 0 - Arduino
// 1 - Simulator
#define SIMULATOR 1
