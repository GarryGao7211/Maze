#include "MouseChecker.h"

namespace sim {

// TODO: For both, ensure that the center is contained within the collision polygon
// TODO: For both, ensure that it fits within the starting tile

bool MouseChecker::isDiscreteInterfaceCompatible(const Mouse& mouse) {
    // TODO: upforgrabs
    return true;
}

bool MouseChecker::isContinuousInterfaceCompatible(const Mouse& mouse) {
    // TODO: upforgrabs
    return true;
}

} // namespace sim
