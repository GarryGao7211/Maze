# tomasz

This is a hardcore maze-generation algorithm that Tomasz Pietruszka wrote. If
you have questions about it, you should ask him directly at
tomaszpi@buffalo.edu.
