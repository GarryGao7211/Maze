// ----- Remember to change the include directive below this line ----- //
#include "AlgorithmTemplate.h"
// ----- Remember to change the include directive above this line ----- //

// ----- Remember to change the class name below this line ----- //
void AlgorithmTemplate::solve(sim::MouseInterface* mouse) {
// ----- Remember to change the class name above this line ----- //

    // ---- REMINDER ---- //
    /* Valid function calls:
     * 1) mouse->wallFront()
     * 2) mouse->wallRight()
     * 3) mouse->wallLeft()
     * 4) mouse->moveForward()
     * 5) mouse->turnRight()
     * 6) mouse->turnLeft()
     */
}

// ----- Helper function definitions should go below this line ----- //

/* ------ EXAMPLE ----------
void AlgorithmTemplate::helperFunction(sim::MouseInterface* mouse) {

}
------- END EXAMPLE ----- */

// ----- Helper function definitions should go above this line ----- //


// NOTE: You may delete the reminders after you've changed the required fields
